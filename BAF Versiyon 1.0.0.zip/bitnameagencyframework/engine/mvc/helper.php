<?php

class Helper extends Database
{

}