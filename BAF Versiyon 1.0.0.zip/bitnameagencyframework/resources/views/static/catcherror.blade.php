<table border="1" width="100%" bordercolor="#FF0000" style="border-collapse: collapse">
	<tr>
		<td width="3%"><b><font face="Times New Roman" color="#FF0000">ERROR:</font></b></td>
		<td width="97%"><font face="Times New Roman" color="#FF0000"><b>&nbsp;{{ $text }}</b></font></td>
	</tr>
	<tr>
		<td colspan="2"><b><font color="#FF0000" face="Times New Roman">Read the 
		Bitname Agency Framework error documentation for more information.</font></b></td>
	</tr>
</table>