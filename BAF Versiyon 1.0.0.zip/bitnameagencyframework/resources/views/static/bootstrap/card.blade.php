   <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mb-30">
                                            <div class="card text-white bg-{{ $class }}">
                                                <div class="card-header">{{ $header }}</div>
                                                <div class="card-body">
                                                    <h5 class="card-title text-white">{{ $title }}</h5>
                                                    <p class="card-text">{{ $text }}</p>
                                                </div>
                                            </div>
                                        </div>