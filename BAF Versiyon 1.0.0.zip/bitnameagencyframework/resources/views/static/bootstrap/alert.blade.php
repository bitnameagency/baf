<div class="alert alert-{{ $class }}" role="alert">
{{ $text }}
</div>