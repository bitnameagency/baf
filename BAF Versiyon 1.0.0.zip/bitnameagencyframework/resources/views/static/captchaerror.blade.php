<div style="margin-top: 1rem;" class="alert alert-danger" role="alert">
{{ $text }}
</div>