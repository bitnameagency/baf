<?php

/**
 * bitnameagency.php
 *
 * Bitname Agency Framework
 *
 * @package    bitnameagency
 * @author     Kazim İNEM
 * @copyright  2021 BitnameAgency
 * @license    http://license.bitnameagency.com Bitname Agency Lisans Sistemi
 * @version    CVS: 2.3.9
 * @link       https://bitnameagency.com
 * DİKKAT: Bu framework "Bitname Agency™" tarafından lisans ile dağıtılmaktadır.
 * DİKKAT: Mevcut sunucu & domain dışında kullanılması, kopyalanması kesinlikle yasaktır.
 * DİKKAT: Tesbiti halinde yasal mercilere bildirim sağlanacaktır.
 * DİKKAT: Bitname Agency lisansı iptal etme hakkını saklı tutar.
 */