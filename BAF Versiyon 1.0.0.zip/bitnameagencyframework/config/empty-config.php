<?php
if (!defined('ABSPATH')){
    exit; 
}

session_start();

define('DB_HOST', '');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_NAME', '');

define('SECURE_KEY', '');