<?php 

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define("homepath", $_SERVER['DOCUMENT_ROOT']); 

?>