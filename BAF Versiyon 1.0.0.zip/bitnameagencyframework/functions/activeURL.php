<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function activeURL(){ 
		
		return $_SERVER['REQUEST_URI'];		
			
	}

